import UIKit
import UserNotifications

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    @IBOutlet weak var notificationView: UITableView!
    @IBOutlet weak var notifyButton: UIButton!
    var notificationList: [NoteC] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        notificationView.dataSource = self
        notificationView.delegate = self
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
            if let error = error {
                print("Error requesting notification permissions: \(error.localizedDescription)")
            } else if granted {
                print("Notification permissions granted.")
            } else {
                print("Notification permissions denied.")
            }
        }
    }
    
    @IBAction func setReminderButtonTapped(_ sender: UIButton) {
            guard !notificationList.isEmpty else {
                print("No notifications to set reminders for.")
                return
            }
            
            // Example: Setting a reminder for the most recent notification
            let notification = notificationList[0] // Adjust index as per your preference
            setReminder(for: notification)
            
            // Alert to confirm reminder is set
            let alert = UIAlertController(
                title: "Reminder Set",
                message: "A reminder has been scheduled for '\(notification.subj)'.",
                preferredStyle: .alert
            )
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        }

        func setReminder(for notification: NoteC) {
            let content = UNMutableNotificationContent()
            content.title = "Reminder: \(notification.subj)"
            content.body = notification.body
            content.sound = .default

            // Example: Schedule a reminder after 10 seconds
            let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 10, repeats: false)

            let request = UNNotificationRequest(
                identifier: UUID().uuidString,
                content: content,
                trigger: trigger
            )

            UNUserNotificationCenter.current().add(request) { error in
                if let error = error {
                    print("Failed to add reminder notification: \(error.localizedDescription)")
                } else {
                    print("Reminder notification scheduled.")
                }
            }
        }

    
    @IBAction func onClickNotify(_ sender: Any) {
        let randomNumber = Int.random(in: 1...6)
        var content: NoteC
        switch randomNumber {
        case 1:
            content = NoteC(subj: "New Job Posting Available", body: "Bahrain Polytechnic Posted", ring: true)
        case 2:
            content = NoteC(subj: "Update On Industry Trends", body: "Check out our graphs!", ring: true)
        case 3:
            content = NoteC(subj: "Interview Request Received", body: "Interview request for your application UX Designer at Bahrain Polytechnic", ring: true)
        case 4:
            content = NoteC(subj: "Application Status Change", body: "You have been shortlisted for your application for UX Designer at Bahrain Polytechnic", ring: true)
        case 5:
            content = NoteC(subj: "Update Deadline for Job Application", body: "Bahrain Polytechnic Software Engineering Job Application deadline in 2 days!", ring: true)
        case 6:
            content = NoteC(subj: "Follow-Up Communication Reminder", body: "Feedback received for your UX designer interview at Bahrain Polytechnic", ring: true)
    default:
    print("Something went wrong.")
            return
        }
        notify(content: content)
        notificationList.append(content)
        if notificationList.count > 5 {
            notificationList.removeFirst()
        }
        notificationView.reloadData()}

    
    
    func notify(content: NoteC) {
        let notificationContent = UNMutableNotificationContent()
        notificationContent.title = content.subj
        notificationContent.body = content.body
        notificationContent.sound = content.ring ? UNNotificationSound.default : nil

        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)

        let request = UNNotificationRequest(identifier: UUID().uuidString, content: notificationContent, trigger: trigger)

        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("Failed to schedule notification: \(error.localizedDescription)")
            } else {
                print("Notification scheduled successfully.")
            }
        }
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return notificationList.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NotificationCell", for: indexPath)
        let notification = notificationList[indexPath.row]
        cell.textLabel?.text = notification.subj
        cell.detailTextLabel?.text = notification.body
        return cell
    }
}
