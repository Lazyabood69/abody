//
//  Notifcation_class.swift
//  Notification-miniProject
//
//  Created by BP-36-201-16N on 26/12/2024.
//

import Foundation

public struct NoteC{
    var subj: String
    var body: String
    var ring: Bool
    init(subj: String, body: String, ring: Bool) {
        self.subj = subj
        self.body = body
        self.ring = ring
    }
    
}

